package iitb.Utils;
/**
 *
 * @author Sunita Sarawagi
 *
 */ 

public class ConfigException extends Exception {
    public ConfigException(String msg) {
	super(msg);
    }
};
