package iitb.Segment;
/**
 *
 * @author Sunita Sarawagi
 *
 */ 

public abstract class Preprocessor {
	public int getCode() {
		return -1;
	}

	public static String preprocess(String s) {
		return null;
	}
};
