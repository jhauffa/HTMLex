package iitb.CRF;
/**
 *
 * @author Sunita Sarawagi
 *
 */ 


public class Util {
    static public void printDbg(String msg) {
	System.out.println(msg);
    }
};


