package iitb.Model;
/**
 *
 * @author Sunita Sarawagi
 *
 */ 

class Token extends Object {
    /*
    String value;
    Token(String s) {value = s;} 
    Token(Object s) {value = (String)s;} 
    boolean equals(Token w) {
	return w.equals(value);
    }
    boolean equalsIgnoreCase(Token w) {
	return w.value.equalsIgnoreCase(value);
    }
    */
};
