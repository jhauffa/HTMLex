# settings for CRF..
export CLASSPATH=$CRF_HOME/lib/CRF.jar:$CRF_HOME/lib/colt.jar:$CRF_HOME/lib/LBFGS.jar:$CLASSPATH
